import SwiftUI

@main
struct MonitorLizardApp: App {
    @StateObject private var viewModel = PRMonitorViewModel()

    var body: some Scene {
        MenuBarExtra("MonitorLizard", systemImage: "lizard") {
            MenuBarView()
                .environmentObject(viewModel)
        }
        .menuBarExtraStyle(.window)

        Settings {
            SettingsView()
        }
    }
}

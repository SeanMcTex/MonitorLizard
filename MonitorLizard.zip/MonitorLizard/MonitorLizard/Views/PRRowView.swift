import SwiftUI

struct PRRowView: View {
    let pr: PullRequest
    @EnvironmentObject var viewModel: PRMonitorViewModel

    @State private var isHovering = false

    var body: some View {
        HStack(spacing: 12) {
            // Status icon
            Text(pr.buildStatus.icon)
                .font(.title2)
                .frame(width: 30)

            VStack(alignment: .leading, spacing: 4) {
                // PR Title
                Text(pr.title)
                    .font(.body)
                    .lineLimit(2)
                    .fixedSize(horizontal: false, vertical: true)

                // Repo and PR number
                HStack(spacing: 4) {
                    Text(pr.repository.name)
                        .font(.caption)
                        .foregroundColor(.secondary)

                    Text("•")
                        .font(.caption)
                        .foregroundColor(.secondary)

                    Text("#\(pr.number)")
                        .font(.caption)
                        .foregroundColor(.secondary)
                }

                // Branch name
                if !pr.headRefName.isEmpty {
                    HStack(spacing: 4) {
                        Image(systemName: "arrow.branch")
                            .font(.caption2)
                            .foregroundColor(.secondary)

                        Text(pr.headRefName)
                            .font(.caption2)
                            .foregroundColor(.secondary)
                            .lineLimit(1)
                    }
                }

                // Build status text
                Text(pr.buildStatus.displayName)
                    .font(.caption2)
                    .foregroundColor(pr.buildStatus.color)
            }

            Spacer()

            // Action buttons (show on hover)
            if isHovering {
                HStack(spacing: 8) {
                    // Watch button
                    Button(action: {
                        viewModel.toggleWatch(for: pr)
                    }) {
                        Image(systemName: pr.isWatched ? "eye.fill" : "eye")
                            .foregroundColor(pr.isWatched ? .blue : .gray)
                    }
                    .buttonStyle(.plain)
                    .help(pr.isWatched ? "Stop watching this PR" : "Watch this PR for completion")

                    // Open in browser button
                    Button(action: {
                        if let url = URL(string: pr.url) {
                            NSWorkspace.shared.open(url)
                        }
                    }) {
                        Image(systemName: "arrow.up.right.square")
                            .foregroundColor(.gray)
                    }
                    .buttonStyle(.plain)
                    .help("Open in GitHub")
                }
            } else if pr.isWatched {
                // Always show watch indicator if watched
                Image(systemName: "eye.fill")
                    .foregroundColor(.blue)
                    .font(.caption)
            }
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 10)
        .background(isHovering ? Color.gray.opacity(0.1) : Color.clear)
        .contentShape(Rectangle())
        .onHover { hovering in
            isHovering = hovering
        }
        .onTapGesture {
            if let url = URL(string: pr.url) {
                NSWorkspace.shared.open(url)
            }
        }
    }
}

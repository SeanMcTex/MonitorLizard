import Foundation

struct PullRequest: Identifiable, Codable, Hashable {
    let number: Int
    let title: String
    let repository: RepositoryInfo
    let url: String
    let author: Author
    let headRefName: String
    let updatedAt: Date
    var buildStatus: BuildStatus
    var isWatched: Bool

    var id: String {
        "\(repository.nameWithOwner)#\(number)"
    }

    struct RepositoryInfo: Codable, Hashable {
        let name: String
        let nameWithOwner: String
    }

    struct Author: Codable, Hashable {
        let login: String
    }

    enum CodingKeys: String, CodingKey {
        case number, title, repository, url, author, updatedAt
        case headRefName, buildStatus, isWatched
    }
}

// Response structures for parsing gh CLI JSON output
struct GHPRSearchResponse: Codable {
    let number: Int
    let title: String
    let repository: Repository
    let url: String
    let author: Author
    let updatedAt: String

    struct Repository: Codable {
        let name: String
        let nameWithOwner: String
    }

    struct Author: Codable {
        let login: String
    }
}

struct GHPRDetailResponse: Codable {
    let number: Int
    let title: String
    let headRefName: String
    let url: String
    let statusCheckRollup: [StatusCheck]?

    struct StatusCheck: Codable {
        let name: String?
        let context: String?
        let status: String?
        let state: String?
        let conclusion: String?
        let __typename: String

        private enum CodingKeys: String, CodingKey {
            case name, context, status, state, conclusion, __typename
        }
    }
}
